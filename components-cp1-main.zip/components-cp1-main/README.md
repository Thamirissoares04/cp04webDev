# Componentes REACT + Vite

### Feito por Matheus Queiroz - RM558801 <br> Deploy final: https://components-cp1.vercel.app/

### Esse projeto faz parte do Checkpoint 1 do 2 Semestre de Web Development na FIAP, a ideia é treinar a componentização de itens com React e o deploy na Vercel.

Link das instruções: https://cherry-client-b8f.notion.site/Orienta-es-CP1-React-c9c2c2b8427b44a6b5338fc43f3c981b

Link do protótipo para copiar no Figma: https://www.figma.com/design/9UoO20oNMIsv7BWpXpRiHP/Plata
